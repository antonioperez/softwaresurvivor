<?php
/**
 * WP-Product-Builder
 *
 *
 * @package   WP-Product-Builder
 * @author    Antonio Perez
 * @license   GPL-3.0
 * @link      https://perezprogramming.com/
 * @copyright 2018 Antonio Perez
 */


namespace ProductBuilder\WPR;
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
/**
 * @subpackage Shortcode
 */
class Shortcode {

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
			self::$instance->do_hooks();
		}
		return self::$instance;
	}

	/**
	 * Initialize the plugin by setting localization and loading public scripts
	 * and styles.
	 *
	 * @since     1.0.0
	 */

	private function __construct() {
		$plugin = Plugin::get_instance();
		$this->plugin_slug = $plugin->get_plugin_slug();
		$this->version = $plugin->get_plugin_version();
		add_shortcode( 'wp-product-builder', array( $this, 'shortcode' ));
		add_action( 'woocommerce_single_product_summary', array( $this, 'addToProductpage' ), 1);
	}


	/**
	 * Handle WP actions and filters.
	 *
	 * @since 	1.0.0
	 */
	private function do_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend_scripts' ) );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'before_calculate_totals'), 10, 1);
		add_filter( 'woocommerce_add_cart_item_data', array($this,'add_cart_item_data'), 10, 3 );
		add_filter( 'woocommerce_get_item_data', array($this,'get_item_data'), 10, 2 );
		add_filter( 'woocommerce_get_cart_item_from_session', array($this, 'get_cart_item_from_session'), 20, 2 );
		add_action( 'woocommerce_add_order_item_meta', array($this, 'add_order_item_meta'), 10, 2 );
		add_filter( 'woocommerce_order_item_product', array($this, 'getorder_item_product'), 10, 2 );
		add_filter( 'woocommerce_order_again_cart_item_data', array($this,'order_again_cart_item_data'), 10, 3 );

		require_once(ABSPATH . 'wp-admin/includes/image.php');
		require_once(ABSPATH . 'wp-admin/includes/file.php');
		require_once(ABSPATH . 'wp-admin/includes/media.php');

	}

	function addToProductpage() {
		global $product;

		$product_show = get_post_meta($product->id,'_show_product_builder');
		$admin_settings = get_option( 'wpr_product_builder_setting');
		$showOnAllProducts = (!empty($admin_settings['showEveryPage']) && $admin_settings['showEveryPage'] === 'yes');	
		$showOnUniqueProduct = (!empty($product_show) &&  $product_show[0] === 'yes');	

		if($showOnAllProducts || $showOnUniqueProduct) {
			remove_action( 'woocommerce_product_thumbnails', 'woocommerce_show_product_thumbnails');
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );
			if($product->id) {
				$content = do_shortcode('[wp-product-builder][/wp-product-builder]');
				echo $content;
			}	
		}
	  }


	/**
	 * Register frontend-specific javascript
	 *
	 * @since     1.0.0
	 */
	public function register_frontend_scripts() {
		wp_register_script( $this->plugin_slug . '-shortcode-script', plugins_url( 'assets/js/shortcode.js', dirname( __FILE__ ) ), array( 'jquery' ), $this->version );
		wp_register_style( $this->plugin_slug . '-shortcode-style', plugins_url( 'assets/css/shortcode.css', dirname( __FILE__ ) ), $this->version );
	}

	public function shortcode( $atts ) {

		wp_enqueue_script( $this->plugin_slug . '-shortcode-script' );
		wp_enqueue_style( $this->plugin_slug . '-shortcode-style' );

		$object_name = 'wpr_object_' . uniqid();
		global $product;
		$avail_options = $this->get_product_attributes($product);
		$admin_settings = get_option( 'wpr_product_builder_setting' );
		$redirectToCart = get_option( 'woocommerce_cart_redirect_after_add' );
		$admin_settings['redirectToCart'] = $redirectToCart;
		
		$product_info = array(
			'id' => $product->id,
			'name' => $product->name,
			'price' => $product->price,
			'description' => $product->description,
			'regular_price' => $product->regular_price,
			'sale_price' => $product->sale_price,
			'status' => $product->status,
			'attributes' => $avail_options,
			'admin_settings' => $admin_settings
		);

		$object = shortcode_atts( array(
			'product' => $product_info,
			'api_nonce'   => wp_create_nonce( 'wp_rest' ),
			'api_url'	  => rest_url( $this->plugin_slug . '/v1/' ),
		), $atts, 'wp-product-builder' );

		wp_localize_script( $this->plugin_slug . '-shortcode-script', $object_name, $object );

		$shortcode = '<div class="wp-product-builder-shortcode" data-object-id="' . $object_name . '"></div>';
		return $shortcode;
	}

	private function get_product_attributes($product){
		$avail_options = array();
		$product_attributes = $product->get_attributes();

		foreach ($product_attributes as $key => $variation) {
			$display_name = $variation->get_name(); 
			$display_name = wc_attribute_label($display_name, $product);
			$avail_options[$key] = $variation->get_data();
			$options = array();

			foreach ($avail_options[$key]['options'] as $id) {
				$term = get_term($id);
				if ($term) {
					$term = $term->to_array();
					if (function_exists('the_field')) {
						//GET ACF attribute image field
						$image = get_field('product_attribute_file_upload', $term['taxonomy'] . '_' . $term['term_id']);
						$term['image'] = $image;
					}
					array_push($options, $term);
				}
			}
			$avail_options[$key]['options'] = $options;
			$avail_options[$key]['display_name'] = $display_name;
		}

		return $avail_options;
	}

	public function before_calculate_totals($cart_obj) {

		if (is_admin() && ! defined('DOING_AJAX')) {
			return;
		}
		// Iterate through each cart item
		foreach( $cart_obj->get_cart() as $key=>$value ) {
			if(isset( $value['sub_total'])) {
				$price = $value['sub_total'];
				$value['data']->set_price( ( $price ) );
			}
		}
	}

	public function calculate_price($post_data, $product_id, $variation_id){

		$product = wc_get_product($product_id);
		$price = floatval($product->get_price());
		$measure_symbols = array('"', "'", '-', "\\");
		$formula_pricing = get_post_meta($product_id,'_decal_formula');
		$is_formula_pricing = 'no';
		$quantity = 1;
		if(!empty($formula_pricing)) {
			$is_formula_pricing = $formula_pricing[0];
		}

		if (!empty($post_data['quantity'])) {
			$quantity = floatval($post_data['quantity']);
		}

		if($product->is_type('variable')){
			$Variation= new \WC_Product_Variation( $variation_id );
			$regular_price = floatval($Variation->regular_price);
			$sales_price = floatval($Variation ->sale_price);

			if (is_numeric($sales_price) && $sales_price > 0) {
				$price = $sales_price;
			} else if (is_numeric($regular_price) && $regular_price > 0) {
				$price = $regular_price;
			}
		}

		$total_price = $price;
		if(!empty($post_data['attribute_pa_measurements'])) {

			$measurement = esc_html($post_data['attribute_pa_measurements']);
			foreach($measure_symbols as $key => $value){
				$measurement= str_replace($value,"",$measurement);
			}

			$measurement_values = explode("x", $measurement);
			$width = floatval($measurement_values[0]);
			$height = floatval($measurement_values[1]);

			if (is_numeric($width) && is_numeric($height)) {
				if ($is_formula_pricing == 'yes') {
					return $this->do_formula_pricing($quantity, $width, $height, $price);
				} else {
					$area = abs($width) * abs($height);
					$total_price = $price * $area;
				}
			}
		}

		$price_per = floatval(number_format($price_per, 2));
		$total_price = floatval(number_format($total_price, 2));
		return array(
			'price_per' => $price,
			'total_price' => $total_price,
			'is_formula_pricing' => $is_formula_pricing
		);
	}

	public function add_cart_item_data( $cart_item_data, $product_id, $variation_id) {
		
		// Has our option been selected?
		if(!empty($_POST['attribute_pa_measurements'])) {
			$measurement = stripslashes(esc_html($_POST['attribute_pa_measurements']));
			$cart_item_data['measurement'] = $measurement;
			$_POST['attribute_pa_measurements'] = $measurement;
			$prices = $this->calculate_price($_POST, $product_id, $variation_id);
			$cart_item_data['sub_total'] = $prices['total_price'];
			$cart_item_data['price_per_unit'] = $prices['price_per'];
		}

		if (!empty($_FILES['custom_artwork'])) {
			$uploadedfile = $_FILES['custom_artwork'];
			$form = array('test_form' => FALSE);
			$movefile = wp_handle_upload($uploadedfile, $form);
			if ($movefile && !isset($movefile['error'])) {
				$cart_item_data['custom_artwork'] = $movefile["url"];
			} else {
				echo $movefile['error'];
			}
		}
		
		return $cart_item_data;
	   }

	public function get_item_data( $other_data, $cart_item ) {

		if (isset($cart_item['measurement'])){
			$other_data[] = array(
				'name' => __( 'Measurement', 'pb-plugin-measurement' ),
				'value' => sanitize_text_field( $cart_item['measurement'] )
			);
		}

		if (isset($cart_item['price_per_unit'])){
			$other_data[] = array(
				'name' => __( 'Price Per Unit', 'pb-plugin-measurement' ),
				'value' => sanitize_text_field( $cart_item['price_per_unit'] )
			);
		}

		if (isset($cart_item['custom_artwork'])){
			$art_url = $cart_item['custom_artwork'];
			$other_data[] = array(
				'name' => __( 'Custom Artwork', 'pb-plugin-artwork' ),
				'value' => "<a href='$art_url' target='_blank'>$art_url</a>"
			);
		}
		return $other_data;
	}

	public function get_cart_item_from_session( $cart_item, $values ) { 
		if ( isset( $values['measurement'] ) ){
			$cart_item['measurement'] = $values['measurement'];
		}
		if ( isset( $values['price_per_unit'] ) ){
			$cart_item['price_per_unit'] = $values['price_per_unit'];
		}

		if ( isset( $values['custom_artwork'] ) ){
			$cart_item['custom_artwork'] = $values['custom_artwork'];
		}

		return $cart_item;
	}

	public function add_order_item_meta( $item_id, $values ) {

		if ( ! empty( $values['measurement'] ) ) {
			woocommerce_add_order_item_meta( $item_id, 'measurement', $values['measurement'] );           
		}

		if ( ! empty( $values['price_per_unit'] ) ) {
			woocommerce_add_order_item_meta( $item_id, 'price_per_unit', $values['price_per_unit'] );           
		}

		if ( ! empty( $values['custom_artwork'] ) ) {
			woocommerce_add_order_item_meta( $item_id, 'custom_artwork', $values['custom_artwork'] );           
		}
	}

	public function get_order_item_product( $cart_item, $order_item ){
 
		if( isset( $order_item['measurement'] ) ){
			$cart_item_meta['measurement'] = $order_item['measurement'];
		}

		if( isset( $order_item['price_per_unit'] ) ){
			$cart_item_meta['price_per_unit'] = $order_item['price_per_unit'];
		}

		if( isset( $order_item['custom_artwork'] ) ){
			$cart_item_meta['custom_artwork'] = $order_item['custom_artwork'];
		}
		return $cart_item;
	}

	public function order_again_cart_item_data( $cart_item, $order_item, $order ){
 
		if(isset($order_item['measurement'])){
			$cart_item_meta['measurement'] = $order_item['measurement'];
		}

		if(isset($order_item['custom_artwork'])){
			$cart_item_meta['custom_artwork'] = $order_item['custom_artwork'];
		}
	 
		return $cart_item;
	 
	}

	public function do_formula_pricing($qty, $width, $height, $base_price) {
		$price = $base_price;
		$formula = ($qty * (($width + $base_price) * ($height + $base_price))) + 576;
		if ($formula < 2976) {
			$price = $formula * 0.37; 
		} else if ($formula < 5376) {
			$price = $formula * 0.34; 
		} else if ($formula < 7776) {
			$price = $formula * 0.31; 
		} else if ($formula < 10176) {
			$price = $formula * 0.27; 
		} else if ($formula >= 10176) {
			$price = $formula * 0.23; 
		}
		
		$price += 2;
		$price = floatval(number_format($price, 2));

		$price_per = $price/$qty;
		$price_per = floatval(number_format($price_per, 2));
		return array(
			'price_per' => $price_per,
			'total_price' => $price,
			'formula' => $formula,
			'qty' => $qty,
			'is_formula_pricing' => 'yes'
		);
	}
}
