<?php
/**
 * WP-Product-Builder-Multi-Step
 *
 *
 * @package   WP-Product-Builder-Multi-Step
 * @author    Antonio Perez
 * @license   GPL-3.0
 * @link      https://perezprogramming.com/
 * @copyright 2018 Antonio Perez
 */

namespace ProductBuilder\WPR;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * @subpackage Plugin
 */
class Plugin {

	/**
	 * The variable name is used as the text domain when internationalizing strings
	 * of text. Its value should match the Text Domain file header in the main
	 * plugin file.
	 *
	 * @since    1.0.0
	 *
	 * @var      string
	 */
	protected $plugin_slug = 'wp-product-builder-multi-step';

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Setup instance attributes
	 *
	 * @since     1.0.0
	 */
	private function __construct() {
		$this->plugin_version = WP_PRODUCT_VERSION;
	}

	/**
	 * Return the plugin slug.
	 *
	 * @since    1.0.0
	 *
	 * @return    Plugin slug variable.
	 */
	public function get_plugin_slug() {
		return $this->plugin_slug;
	}

	/**
	 * Return the plugin version.
	 *
	 * @since    1.0.0
	 *
	 * @return    Plugin slug variable.
	 */
	public function get_plugin_version() {
		return $this->plugin_version;
	}

	/**
	 * Fired when the plugin is activated.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$defaults = array (
				'showEveryPage' => 'no',
				"customCSS" => ".woocommerce-product-gallery {display:none}",
				'optionStyle' => 'row',
				"artworkTerms" => "<h3>Not sure about your artwork?</h3>
					<p>All orders will receive an artwork proof for approval before anything goes into production.
					Please be advised we may need artwork to provide accurate quotes for some products. 
					If you have any other questions about artwork, feel free to contact us via email, phone or chat.</p>",
				'primaryColor' => 
					array ('hsl' => array (
						'h' => 208.10126582277999,
						's' => 0.56834532374100999,
						'l' => 0.72745098039216005,
						'a' => 1,
					),
					'hex' => '#92bce1',
					'rgb' => array (
						'r' => 146,
						'g' => 188,
						'b' => 225,
						'a' => 1,
					),
					'hsv' => array (
						'h' => 208.10126582277999,
						's' => 0.35111111111110999,
						'v' => 0.88235294117647001,
						'a' => 1,
					),
					'oldHue' => 208.10126582277999,
					'source' => 'hex',
					),
				'secondaryColor' => array (
				  'hsl' => array (
					'h' => 0,
					's' => 0,
					'l' => 0.95294117647058996,
					'a' => 1,
				  ),
				  'hex' => '#f3f3f3',
				  'rgb' => array (
					'r' => 243,
					'g' => 243,
					'b' => 243,
					'a' => 1,
				  ),
				  'hsv' => array (
					'h' => 0,
					's' => 0,
					'v' => 0.95294117647058996,
					'a' => 1,
				  ),
				  'oldHue' => 0,
				  'source' => 'hex',
				),
				'buttonColor' => array (
				  'hsl' => array (
					'h' => 5.0793650793651004,
					's' => 0.82532751091703005,
					'l' => 0.55098039215686001,
					'a' => 1,
				  ),
				  'hex' => '#eb3e2e',
				  'rgb' =>array (
					'r' => 235,
					'g' => 62,
					'b' => 46,
					'a' => 1,
				  ),
				  'hsv' => array (
					'h' => 5.0793650793651004,
					's' => 0.80425531914894,
					'v' => 0.92156862745098,
					'a' => 1,
				  ),
				  'oldHue' => 5.0793650793651004,
				  'source' => 'hex',
				),
				'activeTextColor' => array (
				  'hsl' => array (
					'h' => 0,
					's' => 0,
					'l' => 1,
					'a' => 1,
				  ),
				  'hex' => '#ffffff',
				  'rgb' => array (
					'r' => 255,
					'g' => 255,
					'b' => 255,
					'a' => 1,
				  ),
				  'hsv' => array (
					'h' => 0,
					's' => 0,
					'v' => 1,
					'a' => 1,
				  ),
				  'oldHue' => 0,
				  'source' => 'hex',
				),
				'formAreaBackground' => array (
				  'hsl' => array (
					'h' => 0,
					's' => 0,
					'l' => 1,
					'a' => 1,
				  ),
				  'hex' => '#ffffff',
				  'rgb' => array (
					'r' => 255,
					'g' => 255,
					'b' => 255,
					'a' => 1,
				  ),
				  'hsv' => array (
					'h' => 0,
					's' => 0,
					'v' => 1,
					'a' => 1,
				  ),
				  'oldHue' => 0,
				  'source' => 'hex',
				)
		);
		
		add_option( 'wpr_product_builder_setting', $defaults );
		Plugin::add_acf_field();	
	}

	public static function add_acf_field() {
		if(function_exists("acf_add_local_field_group")){
			acf_add_local_field_group(array(
				'key' => 'group_5bb3bce2c111f',
				'title' => 'Product Attribute File Upload',
				'fields' => array(
					array(
						'key' => 'field_5bb3bceca6beb',
						'label' => 'Product Attribute File Upload',
						'name' => 'product_attribute_file_upload',
						'type' => 'file',
						'instructions' => '',
						'required' => 0,
						'conditional_logic' => 0,
						'wrapper' => array(
							'width' => '',
							'class' => '',
							'id' => '',
						),
						'return_format' => 'array',
						'library' => 'uploadedTo',
						'min_size' => '',
						'max_size' => '',
						'mime_types' => '',
					),
				),
				'location' => array(
					array(
						array(
							'param' => 'taxonomy',
							'operator' => '==',
							'value' => 'all',
						),
					),
				),
				'menu_order' => 0,
				'position' => 'normal',
				'style' => 'default',
				'label_placement' => 'top',
				'instruction_placement' => 'label',
				'hide_on_screen' => '',
				'active' => 1,
				'description' => '',
			));			
		}
	}

	/**
	 * Fired when the plugin is deactivated.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		delete_option( 'wpr_product_builder_setting' );
		if(function_exists("acf_remove_local_field")){
			acf_remove_local_field("group_5bb3bce2c111f");
		}
	}
	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	
}
