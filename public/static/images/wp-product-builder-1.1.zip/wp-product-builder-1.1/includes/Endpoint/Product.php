<?php
/**
 * WP-Product-Builder
 *
 *
 * @package   WP-Product-Builder
 * @author    Antonio Perez
 * @license   GPL-3.0
 * @link      https://perezprogramming.com/
 * @copyright 2018 Antonio Perez
 */

namespace ProductBuilder\WPR\Endpoint;
use ProductBuilder\WPR;
use WC;
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
/**
 * @subpackage REST_Controller
 */
class Product {
    /**
	 * Instance of this class.
	 *
	 * @since    0.8.1
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Initialize the plugin by setting localization and loading public scripts
	 * and styles.
	 *
	 * @since     0.8.1
	 */
	private function __construct() {
        $plugin = WPR\Plugin::get_instance();
		$this->plugin_slug = $plugin->get_plugin_slug();
	}

    /**
     * Set up WordPress hooks and filters
     *
     * @return void
     */
    public function do_hooks() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

	/**
	 * Return an instance of this class.
	 *
	 * @since     0.8.1
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
			self::$instance->do_hooks();
		}

		return self::$instance;
	}

    /**
     * Register the routes for the objects of the controller.
     */
    public function register_routes() {
        $version = '1';
        $namespace = $this->plugin_slug . '/v' . $version;
        $endpoint = '/product/';

        register_rest_route( $namespace, $endpoint . "(?P<id>\d+)", array(
            array(
                'methods'               => \WP_REST_Server::READABLE,
                'callback'              => array( $this, 'get_product' ),
                'args' => [
                    'id'
                ],
            ),
        ) );

        register_rest_route( $namespace, $endpoint, array(
            array(
                'methods'               => \WP_REST_Server::CREATABLE,
                'callback'              => array( $this, 'get_product_price' ),
                'args'                  => array(),
            ),
        ));

    }

    /**
     * Get Product Info
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function get_product( $request ) {
        $product_id =  $request->get_param('id');
        
        $product = wc_get_product($product_id);
        $product_info = array();
        if ($product) {
            $product_info = array(
                'id' => $product->id,
                'fda' => $product_id,
                'name' => $product->name,
                'price' => $product->price,
                'description' => $product->description,
                'regular_price' => $product->regular_price,
                'sale_price' => $product->sale_price,
                'attributes' => $product->get_variation_attributes(),
                'status' => $product->status,
                'variations' => $this->get_product_attributes($product)
            );
        }

        return new \WP_REST_Response( array(
            'success' => true,
            'value' => $product_info
        ), 200 );
    }

    /**
     * Update Product Qty
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Request
     */
    public function get_product_price( $request ) {

        $isUpdated = false;
		$variation_id = 0;
        $quantity =  $request->get_param('quantity');
        $product_id =  $request->get_param('product_id');
        $variations = $request->get_param('variations');
		$product = wc_get_product($product_id);
		$plugin = WPR\Shortcode::get_instance();
		$price = 0; 
		
        if ($product && $product->is_type('variable')) {
			$variation_id = \WC_Product_Data_Store_CPT::find_matching_product_variation( $product, $variations );
		}

        $variations['quantity'] = $quantity;
		$price = $plugin->calculate_price($variations, $product_id, $variation_id);		
        return new \WP_REST_Response( array(
            'success' => true,
			'id' => $variation_id,
			'price' => $price
        ), 200 );
    }
        
    private function get_product_attributes($product){
    
		$attributes = $product->get_attributes();
		if ( ! $attributes ) {
			return;
		}
		
		$out = '';
		
		foreach ( $attributes as $attribute ) {
			$name = $attribute->get_name();
			if ( $attribute->is_taxonomy() ) {
	  
				$terms = wp_get_post_terms( $product->get_id(), $name, 'all' );
				// get the taxonomy
				$tax = $terms[0]->taxonomy;
				// get the tax object
				$tax_object = get_taxonomy($tax);
				// get tax label
				if ( isset ($tax_object->labels->singular_name) ) {
					$tax_label = $tax_object->labels->singular_name;
				} elseif ( isset( $tax_object->label ) ) {
					$tax_label = $tax_object->label;
					// Trim label prefix since WC 3.0
					if ( 0 === strpos( $tax_label, 'Product ' ) ) {
					   $tax_label = substr( $tax_label, 8 );
					}                
				}
				$out .= $tax_label . ': ';
				$tax_terms = array();
				foreach ( $terms as $term ) {
					$single_term = esc_html( $term->name );
					array_push( $tax_terms, $single_term );
				}
				$out .= implode(', ', $tax_terms) .  '<br />';
					
			} else {
				$out .= $name . ': ';
				$out .= esc_html(implode( ', ', $attribute->get_options())) . '<br />';
			}
		}
		return $out;
	}

}
