<?php
/**
 * WP-Product-Builder
 *
 *
 * @package   WP-Product-Builder
 * @author    Antonio
 * @license   GPL-3.0
 * @link      https://perezprogramming.com/
 * @copyright 2018 Antonio Perez
 *
 * @wordpress-plugin
 * Plugin Name:       
 
 * Plugin URI:        https://perezprogramming.com/
 * Description:       Multi Step product builder for WooCommerce
 * Version:           1.0.0
 * Author:            Antonio Perez
 * Author URI:        https://perezprogramming.com/
 * Text Domain:       wp-product-builder
 * Domain Path:       /languages
 * 
 * Woo: 12345:342928dfsfhsf8429842374wdf4234sfd
 * WC requires at least: 3.3
 * WC tested up to: 3.4

 * Copyright: © 2009-2015 WooCommerce.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

namespace ProductBuilder\WPR;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


define( 'WP_PRODUCT_VERSION', '1.0.0' );

/**
 * Autoloader
 *
 * @param string $class The fully-qualified class name.
 * @return void
 *
 *  * @since 1.0.0
 */
spl_autoload_register(function ($class) {

    // project-specific namespace prefix
    $prefix = __NAMESPACE__;

    // base directory for the namespace prefix
    $base_dir = __DIR__ . '/includes/';

    // does the class use the namespace prefix?
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        // no, move to the next registered autoloader
        return;
    }

    // get the relative class name
    $relative_class = substr($class, $len);

    // replace the namespace prefix with the base directory, replace namespace
    // separators with directory separators in the relative class name, append
    // with .php
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    // if the file exists, require it
    if (file_exists($file)) {
        require $file;
    }
});

/**
 * Initialize Plugin
 *
 * @since 1.0.0
 */
function init() {
	$wpr = Plugin::get_instance();
	$wpr_shortcode = Shortcode::get_instance();
	$wpr_admin = Admin::get_instance();
    $wpr_rest = Endpoint\Admin::get_instance();
    $wpr_product_rest = Endpoint\Product::get_instance();
}

if(!function_exists("acf_add_local_field_group")){
    add_filter('acf/settings/show_admin', '__return_false');
    include_once( plugin_dir_path(__FILE__) . 'includes/Vendor/advanced-custom-fields/acf.php' );
} 

if (defined('WC_VERSION')) {  
    add_action( 'plugins_loaded', 'ProductBuilder\\WPR\\init' );
}

/**
 * Register activation and deactivation hooks
 */
register_activation_hook( __FILE__, array( 'ProductBuilder\\WPR\\Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ProductBuilder\\WPR\\Plugin', 'deactivate' ) );
