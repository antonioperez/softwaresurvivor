=== Multistep Product Variation Builder ===
Contributors: perezprogramming
Tags: WP Product Variation Builder, woocommerce, product selector, variations
Requires at least: 4.3
Tested up to: 4.3
Requires PHP: 5.6
Stable tag: 4.3
License: GPLv3 or later License
URI: http://www.gnu.org/licenses/gpl-3.0.html